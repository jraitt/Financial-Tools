// Data for tax years 2024, 2025, and 2026.
// Source: IRS Form 8962 Instructions and HHS Poverty Guidelines.
// For a given tax year's PTC calculation, the FPL from the prior calendar year is used.

export type FplLocation = 'CONTIGUOUS_48' | 'ALASKA' | 'HAWAII';

interface FplYearData {
  table: { [key: number]: number };
  perAdditional: number;
}

const FPL_2023: Record<FplLocation, FplYearData> = {
  // Used for tax year 2024
  CONTIGUOUS_48: { table: { 1: 14580, 2: 19720, 3: 24860, 4: 30000, 5: 35140, 6: 40280, 7: 45420, 8: 50560 }, perAdditional: 5140 },
  ALASKA: { table: { 1: 18210, 2: 24640, 3: 31070, 4: 37500, 5: 43930, 6: 50360, 7: 56790, 8: 63220 }, perAdditional: 6430 },
  HAWAII: { table: { 1: 16770, 2: 22680, 3: 28590, 4: 34500, 5: 40410, 6: 46320, 7: 52230, 8: 58140 }, perAdditional: 5910 },
};

const FPL_2024: Record<FplLocation, FplYearData> = {
    // Used for tax year 2025
    CONTIGUOUS_48: { table: { 1: 15060, 2: 20440, 3: 25820, 4: 31200, 5: 36580, 6: 41960, 7: 47340, 8: 52720 }, perAdditional: 5380 },
    ALASKA: { table: { 1: 18810, 2: 25550, 3: 32290, 4: 39030, 5: 45770, 6: 52510, 7: 59250, 8: 65990 }, perAdditional: 6740 },
    HAWAII: { table: { 1: 17310, 2: 23500, 3: 29690, 4: 35880, 5: 42070, 6: 48260, 7: 54450, 8: 60640 }, perAdditional: 6190 },
};

const FPL_2025: Record<FplLocation, FplYearData> = {
    // Used for tax year 2026. Source: https://aspe.hhs.gov/topics/poverty-economic-mobility/poverty-guidelines/2025-poverty-guidelines
    CONTIGUOUS_48: { table: { 1: 15600, 2: 21150, 3: 26700, 4: 32250, 5: 37800, 6: 43350, 7: 48900, 8: 54450 }, perAdditional: 5550 },
    ALASKA: { table: { 1: 19500, 2: 26430, 3: 33360, 4: 40290, 5: 47220, 6: 54150, 7: 61080, 8: 68010 }, perAdditional: 6930 },
    HAWAII: { table: { 1: 17940, 2: 24320, 3: 30700, 4: 37080, 5: 43460, 6: 49840, 7: 56220, 8: 62600 }, perAdditional: 6380 },
};


const FPL_DATA_BY_TAX_YEAR: { [key: number]: Record<FplLocation, FplYearData> } = {
  2024: FPL_2023,
  2025: FPL_2024,
  2026: FPL_2025,
};

export const getFPL = (familySize: number, year: number, location: FplLocation): number => {
  const yearData = FPL_DATA_BY_TAX_YEAR[year]?.[location] || FPL_DATA_BY_TAX_YEAR[2026][location];
  if (!yearData) return 0;
  
  const { table, perAdditional } = yearData;
  
  if (familySize <= 0) return 0;
  if (table[familySize]) {
    return table[familySize];
  }
  const baseFor8 = table[8];
  const additionalPeople = familySize - 8;
  return baseFor8 + additionalPeople * perAdditional;
};

// Applicable Figure Table for calculating contribution amount
// Based on MAGI as a percentage of FPL. This table is valid for tax years 2023-2025
// due to the Inflation Reduction Act, and is assumed to apply for 2026 as well.
const APPLICABLE_FIGURE_TABLE = [
  { fpl_min: 0, fpl_max: 150, start_percent: 0.0, end_percent: 0.0 },
  { fpl_min: 150, fpl_max: 200, start_percent: 0.0, end_percent: 2.0 },
  { fpl_min: 200, fpl_max: 250, start_percent: 2.0, end_percent: 4.0 },
  { fpl_min: 250, fpl_max: 300, start_percent: 4.0, end_percent: 6.0 },
  { fpl_min: 300, fpl_max: 400, start_percent: 6.0, end_percent: 8.5 },
  { fpl_min: 400, fpl_max: Infinity, start_percent: 8.5, end_percent: 8.5 },
];

// Applicable Figure Table that represents the pre-ARPA/IRA law with the "subsidy cliff".
// This is based on the 2020 tax year figures.
const APPLICABLE_FIGURE_TABLE_WITH_CLIFF = [
    { fpl_min: 0, fpl_max: 133, start_percent: 2.01, end_percent: 2.01 },
    { fpl_min: 133, fpl_max: 150, start_percent: 3.02, end_percent: 4.02 },
    { fpl_min: 150, fpl_max: 200, start_percent: 4.02, end_percent: 6.34 },
    { fpl_min: 200, fpl_max: 250, start_percent: 6.34, end_percent: 8.13 },
    { fpl_min: 250, fpl_max: 300, start_percent: 8.13, end_percent: 9.56 },
    { fpl_min: 300, fpl_max: 400, start_percent: 9.56, end_percent: 9.56 },
];

export const getApplicableFigure = (fplPercentage: number, useCliffLogic: boolean = false): number => {
    if (fplPercentage < 0) return 0;

    if (useCliffLogic) {
        if (fplPercentage >= 400) return Infinity; // The "cliff"
        
        const tier = APPLICABLE_FIGURE_TABLE_WITH_CLIFF.find(
            (t) => fplPercentage >= t.fpl_min && fplPercentage < t.fpl_max
        );
        if (!tier) return Infinity; // Should be unreachable, but acts as a safeguard.

        const percentageInRange = (fplPercentage - tier.fpl_min) / (tier.fpl_max - tier.fpl_min);
        const figure = tier.start_percent + percentageInRange * (tier.end_percent - tier.start_percent);
        return figure / 100;
    }

    // Original logic
    if (fplPercentage >= 400) return 0.085;

    const tier = APPLICABLE_FIGURE_TABLE.find(
        (t) => fplPercentage >= t.fpl_min && fplPercentage < t.fpl_max
    );

    if (!tier) return 0.085; // Default to max if something goes wrong

    if (tier.fpl_min === 0) return 0.0;
    
    // Linear interpolation for tiers between 150% and 400%
    const percentageInRange = (fplPercentage - tier.fpl_min) / (tier.fpl_max - tier.fpl_min);
    const figure = tier.start_percent + percentageInRange * (tier.end_percent - tier.start_percent);
    
    return figure / 100;
};


// Repayment Limitation Table
// This table is for the 2024 Tax Year. Data for 2025 and 2026 will be released by the IRS. We assume 2024 values apply for future years for this estimation.
const REPAYMENT_LIMITATION_TABLE_2024 = {
    single: [
        { fpl_max: 200, limit: 350 },
        { fpl_max: 300, limit: 900 },
        { fpl_max: 400, limit: 1500 },
        { fpl_max: Infinity, limit: 2700 }, // For 2024 this cap was removed, but we set a high placeholder for logic
    ],
    other: [ // Married filing jointly, head of household, etc.
        { fpl_max: 200, limit: 700 },
        { fpl_max: 300, limit: 1800 },
        { fpl_max: 400, limit: 3000 },
        { fpl_max: Infinity, limit: 5400 }, // For 2024 this cap was removed
    ],
};

// Note: The American Rescue Plan Act and Inflation Reduction Act removed the repayment limitation for years 2021-2025 for taxpayers with MAGI at or above 400% FPL.
// For this calculator, this rule is assumed to be extended for tax year 2026. For simplicity and to match common tax software, we can treat this as no limit.
export const getRepaymentLimitation = (fplPercentage: number, isSingle: boolean, taxYear: number): number => {
    if (fplPercentage >= 400) return Infinity; 

    // Using 2024 data as 2025/2026 is not yet published. Assume it's the same for now.
    const table = REPAYMENT_LIMITATION_TABLE_2024;
    const filingStatusTable = isSingle ? table.single : table.other;

    const tier = filingStatusTable.find(t => fplPercentage < t.fpl_max);
    return tier ? tier.limit : Infinity;
};