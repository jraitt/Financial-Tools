export interface MonthlyData {
  month: string;
  enrollmentPremium: number; // Column A
  slcspPremium: number;      // Column B
  aptc: number;              // Column C
}
