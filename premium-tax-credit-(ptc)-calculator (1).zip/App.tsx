import React, { useState, useMemo } from 'react';
import { getFPL, getApplicableFigure, FplLocation } from './services/taxData';
import Input from './components/Input';
import ResultsSummary from './components/ResultsSummary';
import CalculationBreakdown from './components/CalculationBreakdown';
import Stepper from './components/Stepper';
import Select from './components/Select';
import EducationalInfo from './components/EducationalInfo';

const App: React.FC = () => {
  const [taxYear, setTaxYear] = useState<number>(2026);
  const [familySize, setFamilySize] = useState<number>(2);
  const [magi, setMagi] = useState<number>(84599);
  const [location, setLocation] = useState<FplLocation>('CONTIGUOUS_48');
  const [subsidyCliff, setSubsidyCliff] = useState<boolean>(false);
  
  const [slcspMonthlyPremium, setSlcspMonthlyPremium] = useState<number>(1545);

  const calculations = useMemo(() => {
    const defaultReturn = { fpl: 0, fplPercentage: 0, applicableFigure: 0, annualContribution: 0, monthlyContribution: 0, totalAllowedPTC: 0, monthlyPTC: 0, totalAptc: 0, netCredit: 0, excessAptc: 0, repaymentLimitation: 0, repaymentAmount: 0 };
    
    // Part I Calculations
    const fpl = getFPL(familySize, taxYear, location);
    if (familySize <= 0 || magi <= 0 || fpl <= 0) {
      return defaultReturn;
    }
    const fplPercentage = (magi / fpl) * 100;
    
    const applicableFigure = getApplicableFigure(fplPercentage, false);
    const annualContribution = isFinite(applicableFigure) ? Math.round(magi * applicableFigure) : Infinity;
    const monthlyContribution = annualContribution / 12;

    // Simplified Part II & III Calculations
    const annualSlcspPremium = slcspMonthlyPremium * 12;
    let totalAllowedPTC = Math.max(0, annualSlcspPremium - annualContribution);

    if (taxYear === 2026 && subsidyCliff && fplPercentage >= 400) {
      totalAllowedPTC = 0;
    }
    
    const monthlyPTC = totalAllowedPTC / 12;
    const totalAptc = 0; 
    
    const difference = totalAllowedPTC - totalAptc;
    const netCredit = Math.max(0, difference);
    const excessAptc = 0; 
    const repaymentAmount = 0;
    const repaymentLimitation = Infinity;
    
    return { 
        fpl, 
        fplPercentage, 
        applicableFigure, 
        annualContribution, 
        monthlyContribution, 
        totalAllowedPTC,
        monthlyPTC,
        totalAptc,
        netCredit,
        excessAptc,
        repaymentLimitation,
        repaymentAmount
    };
  }, [familySize, magi, taxYear, location, slcspMonthlyPremium, subsidyCliff]);
  
  const locationOptions: {id: FplLocation, label: string}[] = [
    {id: 'CONTIGUOUS_48', label: '48 States & DC'},
    {id: 'ALASKA', label: 'Alaska'},
    {id: 'HAWAII', label: 'Hawaii'},
  ];

  return (
    <div className="min-h-screen bg-slate-50 font-sans pb-12">
      {/* Header Gradient Background */}
      <div className="h-48 bg-gradient-to-br from-blue-600 to-teal-400 shadow-md relative z-0">
          <div className="pt-8 text-center text-white">
              <h1 className="text-3xl font-bold tracking-tight">ACA Premium Tax Credit Calculator</h1>
          </div>
      </div>

      <main className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 -mt-24 relative z-10">
        
        <div className="space-y-6">
            {/* Your Information Card */}
            <div className="bg-white p-6 sm:p-8 rounded-2xl shadow-xl border border-slate-100">
              <h2 className="text-2xl font-bold text-slate-800 mb-6 text-center">Your Information</h2>
              
              <div className="space-y-6">
                
                {/* Tax Year */}
                <div className="flex items-center justify-between">
                    <label className="text-sm font-semibold text-slate-700">Select Tax Year</label>
                    <div className="bg-slate-100 p-1 rounded-lg flex">
                        {[2024, 2025, 2026].map((year) => (
                        <button
                            key={year}
                            onClick={() => setTaxYear(year)}
                            className={`px-4 py-1.5 text-sm font-bold rounded-md transition-all ${taxYear === year ? 'bg-white text-blue-600 shadow-sm' : 'text-slate-400 hover:text-slate-600'}`}
                        >
                            {year}
                        </button>
                        ))}
                    </div>
                </div>

                {/* Location */}
                <div className="flex items-center justify-between">
                    <label className="text-sm font-semibold text-slate-700">Location (for FPL)</label>
                    <Select 
                        value={location}
                        onChange={(val) => setLocation(val as FplLocation)}
                        options={locationOptions}
                        className="w-40 sm:w-48"
                    />
                </div>

                {/* Subsidy Cliff */}
                <div className="flex items-center justify-between">
                    <label className="text-sm font-semibold text-slate-700">Assume "Subsidy Cliff" returns</label>
                    <button 
                        onClick={() => setSubsidyCliff(!subsidyCliff)}
                        className={`relative inline-flex h-7 w-12 items-center rounded-full transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 ${subsidyCliff ? 'bg-blue-500' : 'bg-slate-200'}`}
                    >
                        <span className={`inline-block h-5 w-5 transform rounded-full bg-white shadow transition-transform ${subsidyCliff ? 'translate-x-6' : 'translate-x-1'}`} />
                    </button>
                </div>

                {/* Family Size */}
                <div className="flex items-center justify-between">
                    <label className="text-sm font-semibold text-slate-700">Tax Family Size</label>
                    <Stepper value={familySize} onChange={setFamilySize} />
                </div>

                {/* Household Income */}
                <div className="flex items-center justify-between">
                    <label className="text-sm font-semibold text-slate-700">Household Income (MAGI)</label>
                    <div className="w-40 sm:w-48">
                        <Input value={magi} onChange={setMagi} />
                    </div>
                </div>

                {/* SLCSP */}
                <div className="flex items-center justify-between">
                    <label className="text-sm font-semibold text-slate-700">SLCSP Monthly Premium</label>
                    <div className="w-40 sm:w-48">
                        <Input value={slcspMonthlyPremium} onChange={setSlcspMonthlyPremium} />
                    </div>
                </div>

              </div>
            </div>

            {/* Breakdown Card */}
            <CalculationBreakdown 
                fpl={calculations.fpl}
                fplPercentage={calculations.fplPercentage}
                applicableFigure={calculations.applicableFigure}
                annualContribution={calculations.annualContribution}
                monthlyContribution={calculations.monthlyContribution}
                monthlyPTC={calculations.monthlyPTC}
            />

            {/* Results Card */}
            <ResultsSummary 
                totalAllowedPTC={calculations.totalAllowedPTC}
                totalAptc={calculations.totalAptc}
                netCredit={calculations.netCredit}
                excessAptc={calculations.excessAptc}
                repaymentLimitation={calculations.repaymentLimitation}
                repaymentAmount={calculations.repaymentAmount}
            />

            {/* Educational Info Card */}
            <EducationalInfo />
        </div>
      </main>
    </div>
  );
};

export default App;