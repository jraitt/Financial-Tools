import React, { useMemo, useState } from 'react';
import { MonthlyData } from '../types';

interface MonthlyDataTableProps {
    data: MonthlyData[];
    onDataChange: (newData: MonthlyData[]) => void;
}

const formatCurrency = (amount: number) => {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
  }).format(amount);
};

const MonthlyInput: React.FC<{value: number, onChange: (val: number) => void}> = ({value, onChange}) => {
    const [localValue, setLocalValue] = useState(value.toString());

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setLocalValue(e.target.value);
    };

    const handleBlur = () => {
        const num = parseFloat(localValue);
        const finalValue = isNaN(num) ? 0 : num;
        if(finalValue !== value) {
            onChange(finalValue);
        }
        setLocalValue(finalValue.toString());
    };

    React.useEffect(() => {
        setLocalValue(value.toString());
    }, [value]);

    return (
        <input 
            type="number"
            value={localValue}
            onChange={handleChange}
            onBlur={handleBlur}
            className="w-full bg-slate-50 text-slate-900 text-right p-2 rounded-md border border-slate-200 focus:ring-indigo-500 focus:border-indigo-500 transition"
            placeholder="0.00"
            step="0.01"
        />
    )
};


const MonthlyDataTable: React.FC<MonthlyDataTableProps> = ({ data, onDataChange }) => {
    const totals = useMemo(() => {
        return data.reduce((acc, row) => ({
            enrollmentPremium: acc.enrollmentPremium + row.enrollmentPremium,
            slcspPremium: acc.slcspPremium + row.slcspPremium,
            aptc: acc.aptc + row.aptc,
        }), { enrollmentPremium: 0, slcspPremium: 0, aptc: 0 });
    }, [data]);

    const handleCopy = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.checked) {
            const firstMonth = data[0];
            onDataChange(data.map(d => ({...d, ...firstMonth, month: d.month})));
        }
    };
    
    const updateMonthData = (index: number, field: keyof Omit<MonthlyData, 'month'>, value: number) => {
        const newData = [...data];
        newData[index] = { ...newData[index], [field]: value };
        onDataChange(newData);
    };

    return (
        <div className="bg-white p-6 md:p-8 rounded-xl shadow-lg mt-8">
            <div className="flex justify-between items-center mb-6">
                <h2 className="text-2xl font-bold text-slate-800">Monthly Details (Form 1095-A)</h2>
                <label className="flex items-center space-x-2 cursor-pointer">
                    <input type="checkbox" onChange={handleCopy} className="h-4 w-4 rounded text-indigo-600 focus:ring-indigo-500 border-slate-300"/>
                    <span className="text-sm font-medium text-slate-600">Copy January to all months</span>
                </label>
            </div>
            <div className="overflow-x-auto">
                <table className="w-full text-sm">
                    <thead>
                        <tr className="border-b border-slate-200">
                            <th className="text-left font-semibold text-slate-600 p-3">Month</th>
                            <th className="text-right font-semibold text-slate-600 p-3">A. Enrollment Premium</th>
                            <th className="text-right font-semibold text-slate-600 p-3">B. SLCSP Premium</th>
                            <th className="text-right font-semibold text-slate-600 p-3">C. Advance Payment (APTC)</th>
                        </tr>
                    </thead>
                    <tbody>
                        {data.map((row, index) => (
                            <tr key={row.month} className="border-b border-slate-100">
                                <td className="p-2 font-medium text-slate-700">{row.month}</td>
                                <td className="p-2"><MonthlyInput value={row.enrollmentPremium} onChange={(val) => updateMonthData(index, 'enrollmentPremium', val)} /></td>
                                <td className="p-2"><MonthlyInput value={row.slcspPremium} onChange={(val) => updateMonthData(index, 'slcspPremium', val)} /></td>
                                <td className="p-2"><MonthlyInput value={row.aptc} onChange={(val) => updateMonthData(index, 'aptc', val)} /></td>
                            </tr>
                        ))}
                    </tbody>
                    <tfoot>
                        <tr className="bg-slate-100 font-bold text-slate-800">
                            <td className="p-3">Annual Totals</td>
                            <td className="p-3 text-right">{formatCurrency(totals.enrollmentPremium)}</td>
                            <td className="p-3 text-right">{formatCurrency(totals.slcspPremium)}</td>
                            <td className="p-3 text-right">{formatCurrency(totals.aptc)}</td>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>
    );
};

export default MonthlyDataTable;