import React from 'react';

interface InputProps {
  id?: string;
  value: number;
  onChange: (value: number) => void;
  min?: number;
  prefix?: string;
  className?: string;
}

const Input: React.FC<InputProps> = ({ id, value, onChange, min = 0, prefix = '$', className = '' }) => {
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    // Remove non-numeric chars except decimal
    const valStr = e.target.value.replace(/[^0-9.]/g, '');
    const numValue = valStr === '' ? min : parseFloat(valStr);
    onChange(isNaN(numValue) ? min : numValue);
  };

  // Format for display (optional, but raw number usually better for editing)
  // We'll keep it simple for editing
  
  return (
    <div className={`relative flex items-center bg-slate-100 rounded-lg overflow-hidden ${className}`}>
        <div className="absolute left-3 text-slate-400 font-medium pointer-events-none select-none">
            {prefix}
        </div>
        <input
          type="number"
          id={id}
          value={value === 0 ? '' : value}
          onChange={handleChange}
          className="w-full py-2 px-3 pl-8 text-right bg-transparent border-none focus:ring-0 text-slate-700 font-semibold placeholder-slate-300"
          placeholder="0"
          min={min}
        />
    </div>
  );
};

export default Input;