import React from 'react';

interface CalculationBreakdownProps {
  fpl: number;
  fplPercentage: number;
  applicableFigure: number;
  annualContribution: number;
  monthlyContribution: number;
  monthlyPTC: number;
}

const formatCurrency = (amount: number) => {
    if (!isFinite(amount)) return 'N/A';
    return new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'USD',
        minimumFractionDigits: 0,
        maximumFractionDigits: 0,
    }).format(amount);
};

const formatCurrencyDetailed = (amount: number) => {
    if (!isFinite(amount)) return 'N/A';
    return new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'USD',
        minimumFractionDigits: 2,
        maximumFractionDigits: 2,
    }).format(amount);
};

interface BreakdownRowProps {
    lineNumber: string | React.ReactNode;
    label: string;
    description: string;
    value: string;
    isLast?: boolean;
}

const BreakdownRow: React.FC<BreakdownRowProps> = ({ lineNumber, label, description, value, isLast }) => {
    return (
        <div className={`flex items-start py-4 ${!isLast ? 'border-b border-slate-100' : ''}`}>
             <div className="flex-shrink-0 mr-4 mt-0.5">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm ${typeof lineNumber === 'string' ? 'bg-slate-100 text-slate-500' : 'bg-orange-100 text-orange-500'}`}>
                    {lineNumber}
                </div>
            </div>
            <div className="flex-grow">
                <div className="flex justify-between items-baseline mb-1">
                    <h3 className="text-slate-800 font-semibold text-base">{label}</h3>
                    <span className="text-slate-900 font-bold text-lg">{value}</span>
                </div>
                <p className="text-sm text-slate-500 leading-snug max-w-[90%]">{description}</p>
            </div>
        </div>
    );
};

const CalculationBreakdown: React.FC<CalculationBreakdownProps> = ({ 
    fpl, 
    fplPercentage, 
    applicableFigure, 
    annualContribution, 
    monthlyContribution,
    monthlyPTC 
}) => {
  return (
    <div className="bg-white p-6 sm:p-8 rounded-2xl shadow-xl border border-slate-100">
      <h2 className="text-2xl font-bold text-slate-800 mb-6 text-center">Calculations: Form 8962 Part I</h2>
      
      <div className="flex flex-col">
        <BreakdownRow 
            lineNumber="4"
            label="Federal Poverty Line (FPL)"
            description="Based on your tax year, family size, and location."
            value={formatCurrency(fpl)}
        />
        <BreakdownRow 
            lineNumber="5"
            label="Income as % of FPL"
            description="Your household income divided by the FPL."
            value={`${fplPercentage.toFixed(0)}%`}
        />
        <BreakdownRow 
            lineNumber="7"
            label="Applicable Figure"
            description="The percentage of income you're expected to contribute."
            value={isFinite(applicableFigure) ? applicableFigure.toFixed(4) : 'N/A'}
        />
        <BreakdownRow 
            lineNumber="8a"
            label="Annual Contribution"
            description="Your income multiplied by the applicable figure (rounded)."
            value={formatCurrency(annualContribution)}
        />
         <BreakdownRow 
            lineNumber="8b"
            label="Monthly Contribution"
            description="Your annual contribution divided by 12."
            value={formatCurrencyDetailed(monthlyContribution)}
        />
         <BreakdownRow 
            lineNumber={
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5">
                  <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1.41 16.09V20h-2.67v-1.93c-1.71-.36-3.16-1.46-3.27-3.4h1.96c.1 1.05 1.18 1.91 2.53 1.91 1.29 0 2.13-.72 2.13-1.55 0-.8-.67-1.17-1.98-1.48l-1.46-.39C8.49 12.54 7.15 11.22 7.15 9.5c0-1.78 1.38-3.25 3.1-3.51V4h2.67v1.92c1.42.34 2.76 1.28 2.99 3h-1.96c-.18-.74-1.15-1.46-2.48-1.46-1.18 0-1.96.61-1.96 1.37 0 .65.55 1.01 1.68 1.26l1.6.37c2.18.5 3.32 1.91 3.32 3.65 0 1.9-1.37 3.35-3.02 3.59z"/>
                </svg>
            }
            label="Estimated Monthly PTC"
            description="Your estimated monthly premium subsidy."
            value={formatCurrencyDetailed(monthlyPTC)}
            isLast={true}
        />
      </div>
    </div>
  );
};

export default CalculationBreakdown;