import React from 'react';

const EducationalInfo: React.FC = () => {
  const terms = [
    {
      term: "ACA (Affordable Care Act)",
      definition: "Often referred to as 'Obamacare', this comprehensive health care reform law was enacted in March 2010. It aims to make affordable health insurance available to more people."
    },
    {
      term: "PTC (Premium Tax Credit)",
      definition: "A refundable tax credit designed to help eligible individuals and families with low or moderate income afford health insurance purchased through the Health Insurance Marketplace."
    },
    {
      term: "FPL (Federal Poverty Level)",
      definition: "A measure of income issued annually by the Department of Health and Human Services (HHS). Your income relative to the FPL determines your eligibility for subsidies. For example, subsidies are often available for incomes between 100% and 400% of the FPL."
    },
    {
      term: "MAGI (Modified Adjusted Gross Income)",
      definition: "Used to determine eligibility for the PTC. For most people, it is your Adjusted Gross Income (AGI) plus tax-exempt Social Security benefits, tax-exempt interest, and excluded foreign income."
    },
    {
      term: "SLCSP (Second Lowest Cost Silver Plan)",
      definition: "The benchmark plan used to determine your Premium Tax Credit amount. It is the second-lowest priced Silver plan available in your area that covers your family."
    },
    {
      term: "APTC (Advance Premium Tax Credit)",
      definition: "Tax credits paid in advance directly to your insurance company to lower your monthly premiums. When you file your taxes, you reconcile the APTC paid on your behalf with the PTC you are actually eligible for."
    }
  ];

  return (
    <div className="bg-white p-6 sm:p-8 rounded-2xl shadow-xl border border-slate-100">
      <h2 className="text-2xl font-bold text-slate-800 mb-6 text-center">Key Terms & Information</h2>
      <div className="grid gap-6 md:grid-cols-2">
        {terms.map((item, index) => (
          <div key={index} className="bg-slate-50 p-4 rounded-xl border border-slate-100">
            <h3 className="font-bold text-blue-600 mb-2">{item.term}</h3>
            <p className="text-sm text-slate-600 leading-relaxed">{item.definition}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default EducationalInfo;