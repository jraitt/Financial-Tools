import React from 'react';

interface ResultsSummaryProps {
  totalAllowedPTC: number;
  totalAptc: number;
  netCredit: number;
  excessAptc: number;
  repaymentLimitation: number;
  repaymentAmount: number;
}

const ResultsSummary: React.FC<ResultsSummaryProps> = ({ 
    netCredit
}) => {
  return (
    <div className="bg-green-500 rounded-2xl shadow-xl p-8 text-center text-white">
      <h2 className="text-2xl font-bold mb-4">Your Estimated Credit:</h2>
      <div className="text-6xl font-bold tracking-tight">
        {new Intl.NumberFormat('en-US', {
            style: 'currency',
            currency: 'USD',
            maximumFractionDigits: 0
        }).format(netCredit)}
      </div>
    </div>
  );
};

export default ResultsSummary;